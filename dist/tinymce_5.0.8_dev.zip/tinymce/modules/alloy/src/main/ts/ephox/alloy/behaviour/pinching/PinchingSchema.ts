import { FieldSchema, FieldProcessorAdt } from '@ephox/boulder';

export default [
  FieldSchema.strict('onPinch'),
  FieldSchema.strict('onPunch')
];