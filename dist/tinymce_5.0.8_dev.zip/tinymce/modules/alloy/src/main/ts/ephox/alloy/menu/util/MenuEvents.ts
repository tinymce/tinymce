import { Fun } from '@ephox/katamari';

const focus = Fun.constant('alloy.menu-focus');

export {
  focus
};