const resolve = (rest) => {
  return 'ephox-alloy-position-' + rest;
};

export {
  resolve
};