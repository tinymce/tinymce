const debug = function () {
  debugger;
};

const pass = function () { };

export {
  debug,
  pass
};